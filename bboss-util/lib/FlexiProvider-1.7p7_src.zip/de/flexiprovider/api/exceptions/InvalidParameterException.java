package de.flexiprovider.api.exceptions;

public class InvalidParameterException extends
	java.security.InvalidParameterException {

    public InvalidParameterException(String msg) {
	super(msg);
    }

}
