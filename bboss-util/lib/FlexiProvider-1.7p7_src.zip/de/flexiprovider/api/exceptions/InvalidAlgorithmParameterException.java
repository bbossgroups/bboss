package de.flexiprovider.api.exceptions;

public class InvalidAlgorithmParameterException extends
	java.security.InvalidAlgorithmParameterException {

    public InvalidAlgorithmParameterException() {
	super();
    }

    public InvalidAlgorithmParameterException(String msg) {
	super(msg);
    }

}
